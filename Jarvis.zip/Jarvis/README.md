# Jarvis (Android, free Gemini)

1. Free key: aistudio.google.com > Get API key > Create API key (no card needed).
2. Android Studio: File > Open > this Jarvis folder, let Gradle sync, plug in your phone, Run.
3. In the app paste the key, tap "Save key".
4. Tap "Turn on Jarvis accessibility", pick Jarvis, switch it on.
   (If Android says "restricted setting": phone Settings > Apps > Jarvis > menu > Allow restricted settings.)
5. Tap "Talk to Jarvis". Speak. It answers out loud, then listens again. Say "bye" or tap Stop to end.

Free tier is rate limited (about 10 requests/minute); Jarvis waits and retries automatically.
