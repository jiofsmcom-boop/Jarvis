package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** The "brain": talks to Google Gemini (free tier), looks at the screen, picks the next action, repeats. */
object Brain {

    private const val URL_CHAT = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
    // Tries these in order and sticks with the first one that works (Google retires models often).
    private val MODELS = listOf("gemini-flash-latest", "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.1-flash-lite")
    private var modelIdx = 0
    private const val MAX_STEPS = 12

    // Short memory of the conversation so Jarvis can chat naturally.
    private val chat = mutableListOf<String>()

    private const val SYSTEM = """You are Jarvis, a friendly voice assistant that also controls the owner's Android phone.
Each step you get the owner's command, recent conversation, actions already taken, and the current screen.
Reply with ONLY one JSON object: {"action":"...","arg":"...","say":"..."}
Actions:
- open_app (arg = app name)
- tap (arg = exact visible text or description of the element)
- type (arg = text to type into the focused/first input field)
- enter (press Enter/search/send on the keyboard)
- scroll_down, scroll_up
- back, home, recents, notifications, quick_settings
- wait (screen is still loading)
- done (say = what you speak to the owner; use when finished, impossible, or when the command is just a question or chat)
If the command is only a question or conversation (no phone action needed), answer immediately with action done.
Take ONE action per step. Never make payments, delete data, or send messages unless the command explicitly asks for it.
"say" is spoken aloud: natural, friendly, short (1-2 sentences), no emojis or markdown."""

    fun run(command: String, apiKey: String, say: (String) -> Unit) {
        fun finish(text: String) {
            chat.add("Owner: $command")
            chat.add("Jarvis: $text")
            while (chat.size > 8) chat.removeAt(0)
            say(text)
        }

        val svc = JarvisAccessibilityService.instance
        val history = mutableListOf<String>()
        repeat(MAX_STEPS) {
            if (svc != null) Thread.sleep(1000)
            val screen = svc?.screenText() ?: "(accessibility service is off, so you cannot see or control the phone; only chat)"
            val prompt = "Command: $command\n" +
                "Recent conversation: ${chat.joinToString(" | ").ifEmpty { "none" }}\n" +
                "Actions so far: ${history.joinToString("; ").ifEmpty { "none" }}\n" +
                "Screen now:\n$screen"
            val reply = try {
                ask(apiKey, prompt)
            } catch (e: Exception) {
                finish("Sorry, something went wrong. ${e.message}")
                return
            }
            val action = reply.optString("action")
            val arg = reply.optString("arg")
            if (action == "done" || svc == null) {
                finish(reply.optString("say", "Done."))
                return
            }
            val ok = when (action) {
                "open_app" -> svc.openApp(arg)
                "tap" -> svc.tapText(arg)
                "type" -> svc.typeText(arg)
                "enter" -> svc.pressEnter()
                "scroll_down" -> svc.scroll(true)
                "scroll_up" -> svc.scroll(false)
                "wait" -> true
                else -> svc.system(action)
            }
            history.add("$action($arg)" + if (ok) "" else " FAILED")
        }
        finish("I stopped after $MAX_STEPS steps.")
    }

    private fun ask(apiKey: String, prompt: String): JSONObject {
        val body = JSONObject()
            .put("max_tokens", 1500)
            .put("temperature", 0.3)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", prompt))
            )

        var text = ""
        var attempt = 0
        while (true) {
            body.put("model", MODELS[modelIdx])
            val c = URL(URL_CHAT).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $apiKey")
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = c.responseCode
            text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code in 200..299) break
            // Model not available: try the next one in the list.
            if ((code == 404 || code == 400) && modelIdx < MODELS.size - 1) { modelIdx++; continue }
            // Free tier is rate limited: wait and retry a few times on 429.
            if (code == 429 && attempt < 3) { attempt++; Thread.sleep(7000); continue }
            throw Exception("Gemini error $code: ${text.take(150)}")
        }

        val out = JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        if (!out.contains('{')) throw Exception("Empty reply from model, try again")
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }
}
