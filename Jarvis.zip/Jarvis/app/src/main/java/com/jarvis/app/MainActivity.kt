package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.Locale

/**
 * Ears + voice. Tap "Talk to Jarvis" once: it listens, answers out loud, then listens again
 * (conversation mode) until you tap the button again or say "stop" / "bye".
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var logView: TextView
    private lateinit var keyBox: EditText
    private lateinit var mic: Button
    private var recognizer: SpeechRecognizer? = null
    @Volatile private var convo = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        logView = findViewById(R.id.log)
        keyBox = findViewById(R.id.key)
        mic = findViewById(R.id.mic)
        keyBox.setText(prefs.getString("key", ""))

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            log("Key saved.")
        }
        findViewById<Button>(R.id.access).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        mic.setOnClickListener {
            if (convo) stopConvo() else { convo = true; mic.text = "🛑  Stop"; listen() }
        }
    }

    override fun onInit(status: Int) {
        tts.language = Locale.getDefault()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onError(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (convo) runOnUiThread { listen() }   // talk, then listen again
            }
        })
    }

    private fun stopConvo() {
        convo = false
        recognizer?.cancel()
        tts.stop()
        runOnUiThread { mic.text = "🎤  Talk to Jarvis" }
    }

    private fun log(t: String) = runOnUiThread { logView.append(t + "\n") }

    private fun say(t: String) {
        log("Jarvis: $t")
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val cmd = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                log("You: $cmd")
                val lower = cmd.lowercase()
                if (lower == "stop" || lower.contains("bye") || lower.contains("stop listening")) {
                    say("Okay, talk to you later.")
                    convo = false
                    runOnUiThread { mic.text = "🎤  Talk to Jarvis" }
                    return
                }
                val key = prefs.getString("key", "") ?: ""
                if (key.isEmpty()) {
                    convo = false
                    runOnUiThread { mic.text = "🎤  Talk to Jarvis" }
                    say("Please add your Gemini API key first.")
                    return
                }
                Thread { Brain.run(cmd, key) { say(it) } }.start()
            }
            override fun onError(error: Int) {
                // No speech / timeout: end conversation mode so it doesn't loop forever.
                log("Didn't catch that. Tap the button to talk again.")
                stopConvo()
            }
            override fun onReadyForSpeech(params: Bundle?) { log("Listening...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else stopConvo()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
